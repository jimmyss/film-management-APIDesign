package com.example.jpa_demo.config;

public class Constants {
    public static final String SECRET = "niensu24efe465dfggf";
}
